var dataset;

d3.json("oscar_winners.json", function (data) {
    dataset = data;
    
      
})

}
